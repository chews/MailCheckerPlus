var buildID = 0;
var pluginUpdated = false;
var pluginNamespace = 'mailcheckerplus';
var pluginWebsite = 'www.mailcheckerplus.com';
var isHttps_capable = false;
var ad_tag_300='<iframe id=\'a47abb2d\' name=\'a47abb2d\' src=\'http://www.iicdn.com/www/delivery/afr.php?zoneid=55&refresh=60\' frameborder=\'0\' scrolling=\'no\' width=\'300\' height=\'250\'><a href=\'http://www.iicdn.com/www/delivery/ck.php?n=ad2e870b\' target=\'_blank\'><img src=\'http://www.iicdn.com/www/delivery/avw.php?zoneid=6&amp;n=ad2e870b\' border=\'0\' alt=\'\' /></a></iframe>';
var ad_tag_728='<iframe id=\'a47abb2d1\' name=\'a47abb2d1\' src=\'http://www.iicdn.com/www/delivery/afr.php?zoneid=56&refresh=60\' frameborder=\'0\' scrolling=\'no\' width=\'728\' height=\'90\'><a href=\'http://www.iicdn.com/www/delivery/ck.php?n=ad2e870b1\' target=\'_blank\'><img src=\'http://www.iicdn.com/www/delivery/avw.php?zoneid=6&amp;n=ad2e870b1\' border=\'0\' alt=\'\' /></a></iframe>';
